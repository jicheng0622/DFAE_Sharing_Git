/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/* FreeRTOS kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"

/* Freescale includes. */
#include "fsl_device_registers.h"
#include "fsl_debug_console.h"
#include "board.h"

#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_mmc.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
/*! @brief Data block count accessed in card */
#define DATA_BLOCK_COUNT (5U)
/*! @brief Start data block number accessed in card, 1MB backward */
#define DATA_BLOCK_START (1024*1024/FSL_SDMMC_DEFAULT_BLOCK_SIZE)
/*! @brief The first group to erase, Group size = 1KB */
#define ERASE_GROUP_START (DATA_BLOCK_START/2)
/*! @brief The last group to erase */
#define ERASE_GROUP_END ((DATA_BLOCK_START/2)+1)
/*! @brief Data buffer size */
#define DATA_BUFFER_SIZE (FSL_SDMMC_DEFAULT_BLOCK_SIZE * DATA_BLOCK_COUNT)

/* Task priorities. */
#define emmc_test_task_PRIORITY (configMAX_PRIORITIES - 1)
/*******************************************************************************
 * Prototypes
 ******************************************************************************/
static void emmc_test_task(void *pvParameters);
static void BOARD_USDHCClockConfiguration(void);
static int mmccard_debugtest(void);
static void CardInformationLog(mmc_card_t *card);

/*******************************************************************************
 * Variables
 ******************************************************************************/

/*! @brief State in Card driver */
mmc_card_t g_mmc;

/* @brief decription about the read/write buffer
* The size of the read/write buffer in this driver example is multiple of 512, since DDR mode support 512-byte
* block size only and our middleware switch the timing mode automatically per device capability. You can define the
* buffer size to meet your requirement.If the card support partial access, you can also re-define the block size.
* The address of the read/write buffer should align to the specific DMA data buffer address align value if
* DMA transfer is used, otherwise the buffer address is not important.
* At the same time buffer address/size should be aligned to the cache line size if cache is support.
*/
/*! @brief Data written to the card */
SDK_ALIGN(uint8_t g_dataWrite[SDK_SIZEALIGN(DATA_BUFFER_SIZE, SDMMC_DATA_BUFFER_ALIGN_CACHE)],
          MAX(SDMMC_DATA_BUFFER_ALIGN_CACHE, SDMMCHOST_DMA_BUFFER_ADDR_ALIGN));
/*! @brief Data read from the card */
SDK_ALIGN(uint8_t g_dataRead[SDK_SIZEALIGN(DATA_BUFFER_SIZE, SDMMC_DATA_BUFFER_ALIGN_CACHE)],
          MAX(SDMMC_DATA_BUFFER_ALIGN_CACHE, SDMMCHOST_DMA_BUFFER_ADDR_ALIGN));
/*******************************************************************************
 * Code
 ******************************************************************************/
/*!
 * @brief Application entry point.
 */
int main(void)
{
    /* Init board hardware. */
    BOARD_ConfigMPU();
    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();
    if (xTaskCreate(emmc_test_task, "Emmc_Test_Task", configMINIMAL_STACK_SIZE + 10, NULL, emmc_test_task_PRIORITY, NULL) != pdPASS)
    {
        PRINTF("Task creation failed!.\r\n");
        while (1)
            ;
    }
    vTaskStartScheduler();
    for (;;)
        ;
}

/*!
 * @brief Task responsible for printing of "Hello world." message.
 */
static void emmc_test_task(void *pvParameters)
{
	  /* Define the init structure for the output LED pin*/
    gpio_pin_config_t led_config = {kGPIO_DigitalOutput, 0, kGPIO_NoIntmode};
		
		/* Init output LED GPIO. */
    GPIO_PinInit(BOARD_INITPINS_LED_GPIO, BOARD_INITPINS_LED_PIN, &led_config);
	
		PRINTF("emmc test task runing...\r\n");
    
		mmccard_debugtest();
		
		for (;;)
    {
        
       GPIO_PortToggle(BOARD_INITPINS_LED_GPIO, 1u << BOARD_INITPINS_LED_PIN);
			 vTaskDelay(1*configTICK_RATE_HZ);//Delay 2s  
    }
}

static void BOARD_USDHCClockConfiguration(void)
{
    /*configure system pll PFD0 fractional divider to 24*/
    CLOCK_InitSysPfd(kCLOCK_Pfd0, 24U);//PLL2_PFD0=396MHz
    /* Configure USDHC clock source and divider */
    CLOCK_SetDiv(kCLOCK_Usdhc1Div, 1U);//uSDHC_Clk_Root = 396/2 = 198MHz
    CLOCK_SetMux(kCLOCK_Usdhc1Mux, 1U);//uSDHC_Clk_Src = PLL2_PFD0
}

/*! @brief Main function */
static int mmccard_debugtest(void)
{
    mmc_card_t *card = &g_mmc;
    bool isReadOnly;
    bool failedFlag = false;

	  BOARD_USDHCClockConfiguration();//uSDHC clock source is 198MHz=PLL2_PFD0/2
	
    card->host.base = MMC_HOST_BASEADDR;
    card->host.sourceClock_Hz = MMC_HOST_CLK_FREQ;

    /* MMC card VCC supply, only allow 3.3 or 1.8v, depend on your board config.
    * If a power reset circuit is avaliable on you board for mmc, and 1.8v is supported,
    * #define BOARD_USDHC_MMCCARD_POWER_CONTROL_INIT()
    * #define BOARD_USDHC_MMCCARD_POWER_CONTROL(state)
    * in board.h must be implemented.
    * User can remove preset the voltage window and sdmmc will switch VCC automatically. */
    card->hostVoltageWindowVCC = BOARD_MMC_VCC_SUPPLY;
    /* Init card. */
    if (MMC_Init(card))
    {
        PRINTF("\n MMC card init failed \n");
        return -1;
    }
    /* card information log */
    CardInformationLog(card);

    PRINTF("\r\nRead/Write the card continuously until encounter error.... \r\n");
    /* Check if card is readonly. */
    isReadOnly = MMC_CheckReadOnly(card);
    if (isReadOnly)
    {
			PRINTF("\r\nRead one data block......\r\n");
			if (kStatus_Success != MMC_ReadBlocks(card, g_dataRead, DATA_BLOCK_START, 1U))
			{
					PRINTF("Read one data block failed.\r\n");
				  failedFlag = true;
          goto quit;
			}
			if (kStatus_Success != MMC_ReadBlocks(card, g_dataRead+card->blockSize, DATA_BLOCK_START+1, 1U))
			{
					PRINTF("Read one data block failed.\r\n");
				  failedFlag = true;
          goto quit;
			}

			PRINTF("Read multiple data blocks......\r\n");
			if (kStatus_Success != MMC_ReadBlocks(card, g_dataRead, DATA_BLOCK_START, DATA_BLOCK_COUNT))
			{
					PRINTF("Read multiple data blocks failed.\r\n");
					failedFlag = true;
					goto quit;
			}
    }
    else
    {
        memset(g_dataWrite, 1U, sizeof(g_dataWrite));

				PRINTF("\r\nWrite/read one data block......\r\n");
				if (kStatus_Success != MMC_WriteBlocks(card, g_dataWrite, DATA_BLOCK_START, 1U))
				{
						PRINTF("Write one data block failed.\r\n");
						failedFlag = true;
						goto quit;
				}

				memset(g_dataRead, 0U, sizeof(g_dataRead));
				if (kStatus_Success != MMC_ReadBlocks(card, g_dataRead, DATA_BLOCK_START, 1U))
				{
						PRINTF("Read one data block failed.\r\n");
						failedFlag = true;
						goto quit;
				}

				PRINTF("Compare the read/write content......\r\n");
				if (memcmp(g_dataRead, g_dataWrite, FSL_SDMMC_DEFAULT_BLOCK_SIZE))
				{
						PRINTF("The read/write content isn't consistent.\r\n");
						failedFlag = true;
						goto quit;
				}
				PRINTF("The read/write content is consistent.\r\n");

				PRINTF("Write/read multiple data blocks......\r\n");
				if (kStatus_Success != MMC_WriteBlocks(card, g_dataWrite, DATA_BLOCK_START, DATA_BLOCK_COUNT))
				{
						PRINTF("Write multiple data blocks failed.\r\n");
						failedFlag = true;
						goto quit;
				}

				memset(g_dataRead, 0U, sizeof(g_dataRead));
				if (kStatus_Success != MMC_ReadBlocks(card, g_dataRead, DATA_BLOCK_START, DATA_BLOCK_COUNT))
				{
						PRINTF("Read multiple data blocks failed.\r\n");
						failedFlag = true;
						goto quit;
				}

				PRINTF("Compare the read/write content......\r\n");
				if (memcmp(g_dataRead, g_dataWrite, FSL_SDMMC_DEFAULT_BLOCK_SIZE * DATA_BLOCK_COUNT))
				{
						PRINTF("The read/write content isn't consistent.\r\n");
						failedFlag = true;
						goto quit;
				}
				PRINTF("The read/write content is consistent.\r\n");

				PRINTF("Erase data groups......\r\n");
				if (kStatus_Success != MMC_EraseGroups(card, ERASE_GROUP_START, ERASE_GROUP_END))
				{
						PRINTF("\n Erases blocks failed \n");
						failedFlag = true;
						goto quit;
				}
    }

quit:
		if(failedFlag == true)
			PRINTF("\r\nThe emmc r/w example run failed!\r\n");
		else
      PRINTF("\r\nThe emmc r/w example run successfully!\r\n");

    //MMC_Deinit(card);

}

static void CardInformationLog(mmc_card_t *card)
{
    assert(card);

    PRINTF("\r\nCard user partition size %d * %d bytes\r\n", card->blockSize, card->userPartitionBlocks);
    PRINTF("\r\nWorking condition:\r\n");

    if (card->hostVoltageWindowVCC == kMMC_VoltageWindows270to360)
    {
        PRINTF("\r\n  Voltage: VCC - 2.7V ~ 3.3V");
    }
    else if (card->hostVoltageWindowVCC == kMMC_VoltageWindow170to195)
    {
        PRINTF("\r\n  Voltage: VCC - 1.7V ~ 1.95V");
    }
    if (card->hostVoltageWindowVCCQ == kMMC_VoltageWindows270to360)
    {
        PRINTF("  VCCQ - 2.7V ~ 3.3V\r\n");
    }
    else if (card->hostVoltageWindowVCCQ == kMMC_VoltageWindow170to195)
    {
        PRINTF("  VCCQ - 1.7V ~ 1.95V\r\n");
    }
    else if (card->hostVoltageWindowVCCQ == kMMC_VoltageWindow120)
    {
        PRINTF("  VCCQ - 1.2V\r\n");
    }

    if (card->busTiming == kMMC_HighSpeedTimingNone)
    {
        PRINTF("\r\n  Timing mode: Default");
    }
    else if (card->busTiming == kMMC_HighSpeedTiming)
    {
        PRINTF("\r\n  Timing mode: High Speed\r\n");
    }
    else if (card->busTiming == kMMC_HighSpeed200Timing)
    {
        PRINTF("\r\n  Timing mode: HS200\r\n");
    }
    else if (card->busTiming == kMMC_HighSpeed400Timing)
    {
        PRINTF("\r\n  Timing mode: HS400\r\n");
    }

    if (card->busWidth == kMMC_DataBusWidth4bitDDR)
    {
        PRINTF("\r\n  Bus width: 4-bit DDR\r\n");
    }
    else if (card->busWidth == kMMC_DataBusWidth8bitDDR)
    {
        PRINTF("\r\n  Bus width: 8-bit DDR\r\n");
    }
    else if (card->busWidth == kMMC_DataBusWidth8bit)
    {
        PRINTF("\r\n  Bus width: 8-bit\r\n");
    }
    else if (card->busWidth == kMMC_DataBusWidth4bit)
    {
        PRINTF("\r\n  Bus width: 4-bit\r\n");
    }
    else if (card->busWidth == kMMC_DataBusWidth1bit)
    {
        PRINTF("\r\n  Bus width: 1-bit\r\n");
    }
    
    PRINTF("\r\n  Freq : %d HZ\r\n", card->busClock_Hz);
}
