import sys, os

kBootDeviceMemXipSize_FlexspiNor   = 0x08000000 #128MB
kBootDeviceMemXipSize_QuadspiNor   = 0x08000000 #128MB

kRamFreeSpaceStart_LoadCommOpt        = 0x0010c000
kRamFreeSpaceStart_LoadCfgBlock       = 0x0010d000
