import sys, os

kMemBlockOffset_FDCB   = 0x400

kMemBlockSize_FDCB     = 0x200


